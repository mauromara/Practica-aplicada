<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Historial Citas</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="Stylesheet" type="text/css" href="../css/estilo_formularios.css">
    </head>
    <body>
        <header class="primeroE">
                    <img src="../img/logo.png" alt="logotipo">
                    <p>CLINICA CORPUS CHRISTI</p>
        </header>
       <header class="segundoe">
           <a href="../salir.php"><div id="boton1" class="redes">Cerrar</div></a>
       </header>
       <main>
           <aside id="derecha">
               <form action="validar.php" method="POST" class="ingres">
                    <h1 class="titul">Paciente de la clinica</h1>
                    <a href="/corpus/form/programar_cita.php"><div>Programar Cita</div></a>
                    <a href="/corpus/form/cancelar_cita.php"><div>Cancelar Cita</div></a>
                    <a href="#"><div>Historial de Citas</div></a>
              </form>
           </aside>
           <aside id="izquierda">
            <h2 class="relato">HISTORIAL CITAS</h2>
               <form class="mision">

                   
                   
                   

               </form>
           </aside>
       </main>
       
      </body>
</html>
